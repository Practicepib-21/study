﻿using System;
using System.Collections.Generic;
using System.Text;

namespace System.Arithmetic.Tests.Attributes
{
  public  class MyFactAttribute:Attribute
    {

    }
}
